import React, { useState, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import axios from "axios";
import "../styles/adminDashboard.css";
import "bootstrap/dist/css/bootstrap.min.css";
import { Container, Row, Col, Input, Button, Form, Card } from "reactstrap";
import Helmet from "../components/Helmet/Helmet";
import JobItem from "../components/UI/JobItem";
import jData from "../assets/data/jobData";

export function AdminDashboard() {
  const [admin, setAdmin] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [filteredJobs, setFilteredJobs] = useState(jData);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchAdminProfile = async () => {
      try {
        const username = localStorage.getItem("username");
        if (!username) {
          console.error("Admin username not found in localStorage");
          navigate("/admin/login");
          return;
        }

        const response = await axios.get(`http://localhost:7202/api/auth/get/${username}`);
        console.log("Admin profile data:", response.data);
        setAdmin(response.data);
      } catch (error) {
        console.error("Error fetching admin profile:", error);
        navigate("/admin/login");
      }
    };

    fetchAdminProfile();
  }, [navigate]);

  // Handle logout
  const handleLogout = () => {
    localStorage.removeItem("username");
    navigate("/home");
  };

  // Handle job search
  const handleSearch = (e) => {
    const query = e.target.value.toLowerCase();
    setSearchTerm(query);
    setFilteredJobs(
      query ? jData.filter((job) => job.title.toLowerCase().includes(query)) : jData
    );
  };

  if (!admin) {
    return <div className="loading text-center mt-5">Loading...</div>;
  }

  return (
    <Helmet title="Admin Dashboard">
      {/* Navbar */}
      <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
        <div className="container-fluid">
          <a className="navbar-brand fw-bold" href="#">TalentBridge Admin</a>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <ul className="navbar-nav ms-auto">
              <li className="nav-item">
                <Link className="nav-link text-white" to="/postjob">ManageJobs</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link text-white" to="/viewstudent">ViewStudents</Link>
              </li>
              
              <li className="nav-item">
                <button className="btn btn-danger ms-3" onClick={handleLogout}>Logout</button>
              </li>
            </ul>
          </div>
        </div>
      </nav>

      {/* Admin Info */}
      <Container className="mt-4 text-center">
        <h1 className="fw-bold">Welcome, {admin.firstName || admin.userName}!</h1>
        <p className="text-muted">Manage job listings and track users.</p>
      </Container>

    </Helmet>
  );
}

export default AdminDashboard;
