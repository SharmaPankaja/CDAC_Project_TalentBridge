﻿using Microsoft.AspNetCore.Mvc;
using WebApplication2.Data;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : Controller
    {
        private readonly AdminDbContext adminDbContext;

        public AdminController(AdminDbContext adminDbContext)
        {
            this.adminDbContext = adminDbContext;
        }

        [HttpPost]
        [Route("/add")]
        public async Task<IActionResult> addAdmin(Admin admin)
        {
            await adminDbContext.admins.AddAsync(admin);
            await adminDbContext.SaveChangesAsync();
            return View(admin);
        }


    }
}
