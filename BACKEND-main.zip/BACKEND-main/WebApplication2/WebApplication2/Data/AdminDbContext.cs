﻿using Microsoft.EntityFrameworkCore;
using WebApplication2.Models;

namespace WebApplication2.Data
{
    public class AdminDbContext : DbContext
    {
       public AdminDbContext(DbContextOptions options) : base(options)
        {

        }
        public DbSet<Admin> admins { get; set; }
    }
}
